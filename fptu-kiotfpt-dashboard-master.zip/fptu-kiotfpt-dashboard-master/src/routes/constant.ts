export const ROUTE = {
    // auth
    SIGN_IN: '/',
    BEGIN_TO_SELLER: '/begin-to-seller',
    // seller
    SELLER: '/seller',
    // admin
    ADMIN: '/admin',
};
