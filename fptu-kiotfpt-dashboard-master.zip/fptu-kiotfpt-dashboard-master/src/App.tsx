import RootRoutes from "./routes/routes";

function App() {
  return (
    <div className="">
      <RootRoutes />
    </div>
  );
}
export default App;
